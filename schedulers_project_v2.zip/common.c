// common.c: parser flexível, utilitários, impressão de Gantt e métricas
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct {
    char name[64];
    int arrival;
    int burst;
    int priority;
    // Métricas por tarefa
    int start_time;     // primeira vez que executa (response)
    int finish_time;    // término
    int waiting_time;   // soma dos períodos esperando na fila
    int turnaround;     // finish - arrival
    int response;       // start_time - arrival
} Task;

typedef struct {
    Task* v;
    int n;
    int quantum_default; // lido do arquivo, se houver QUANTUM=
} TaskList;

// Trim
static char* ltrim(char* s) { while(isspace((unsigned char)*s)) s++; return s; }
static void rtrim_inplace(char* s) {
    int n = (int)strlen(s);
    while(n>0 && isspace((unsigned char)s[n-1])) s[--n] = 0;
}

// Le linhas ignorando comentários
static int parse_line(char* line, Task* out, int* quantum) {
    char* p = ltrim(line);
    rtrim_inplace(p);
    if (*p == 0) return 0;            // vazia
    if (*p == '#' || *p == ';') return 0; // comentário

    // QUANTUM=
    if (strncasecmp(p, "QUANTUM=", 8) == 0) {
        int q = atoi(p+8);
        if (q > 0) *quantum = q;
        return 0;
    }

    // Suporta CSV com vírgulas ou espaço
    char buf[256];
    strncpy(buf, p, sizeof(buf));
    buf[sizeof(buf)-1] = 0;

    // Troca vírgulas por espaços
    for (char* t = buf; *t; ++t) if (*t == ',') *t = ' ';

    Task t;
    if (sscanf(buf, "%63s %d %d %d", t.name, &t.arrival, &t.burst, &t.priority) == 4) {
        *out = t;
        return 1;
    }
    return -1; // formato inválido
}

int read_tasks(const char* path, TaskList* out) {
    FILE* f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "Erro ao abrir arquivo: %s\n", path);
        return -1;
    }
    int cap = 16;
    out->v = (Task*)malloc(sizeof(Task)*cap);
    out->n = 0;
    out->quantum_default = 0;
    char line[512];

    while (fgets(line, sizeof(line), f)) {
        Task t;
        int q = out->quantum_default;
        int r = parse_line(line, &t, &q);
        if (r == 1) {
            if (out->n == cap) {
                cap *= 2;
                out->v = (Task*)realloc(out->v, sizeof(Task)*cap);
            }
            // zera métricas
            t.start_time = -1;
            t.finish_time = t.waiting_time = t.turnaround = t.response = 0;
            out->v[out->n++] = t;
        } else if (r == 0) {
            // comentário/vazio/QUANTUM
            out->quantum_default = q;
        } else {
            fprintf(stderr, "Linha inválida: %s", line);
        }
    }
    fclose(f);
    return 0;
}

void free_tasks(TaskList* tl) {
    free(tl->v);
    tl->v = NULL;
    tl->n = 0;
}

// Impressão de um "Gantt" textual a partir de arrays de labels e tempos
void print_gantt(const char** labels, const int* starts, const int* ends, int m) {
    // Linha do tempo
    printf("\nGantt (texto):\n");
    // Barra com segmentos
    printf("   ");
    for (int i=0;i<m;i++) {
        int len = ends[i] - starts[i];
        printf("|%s", labels[i]);
        for (int k=0;k<(len>1?len-1:0);++k) printf("-");
    }
    printf("|\n   ");
    // Marcas de tempo
    printf("%d", starts[0]);
    for (int i=0;i<m;i++) {
        int len = ends[i] - starts[i];
        for (int k=0;k<len; ++k) printf(" ");
        printf("%d", ends[i]);
    }
    printf("\n\n");
}

// Métricas agregadas
void print_metrics(Task* tasks, int n, int makespan, int cpu_busy) {
    double avg_wait=0, avg_turn=0, avg_resp=0;
    for (int i=0;i<n;i++) {
        avg_wait += tasks[i].waiting_time;
        avg_turn += tasks[i].turnaround;
        avg_resp += tasks[i].response;
    }
    avg_wait /= n; avg_turn /= n; avg_resp /= n;
    double throughput = (double)n / (double)makespan;
    double cpu_util = makespan>0 ? (100.0 * (double)cpu_busy / (double)makespan) : 0.0;

    printf("MÉTRICAS:\n");
    printf("  Média Waiting Time   = %.2f\n", avg_wait);
    printf("  Média Turnaround     = %.2f\n", avg_turn);
    printf("  Média Response Time  = %.2f\n", avg_resp);
    printf("  Throughput           = %.3f processos/unidade de tempo\n", throughput);
    printf("  CPU Utilization      = %.1f%%\n\n", cpu_util);
}