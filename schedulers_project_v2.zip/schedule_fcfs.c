#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Declarações compartilhadas (em common.c)
typedef struct {
    char name[64];
    int arrival;
    int burst;
    int priority;
    int start_time, finish_time, waiting_time, turnaround, response;
} Task;
typedef struct { Task* v; int n; int quantum_default; } TaskList;

int read_tasks(const char* path, TaskList* out);
void free_tasks(TaskList* tl);
void print_gantt(const char** labels, const int* starts, const int* ends, int m);
void print_metrics(Task* tasks, int n, int makespan, int cpu_busy);

static int cmp_arrival(const void* a, const void* b) {
    const Task* x = (const Task*)a;
    const Task* y = (const Task*)b;
    if (x->arrival != y->arrival) return x->arrival - y->arrival;
    return 0;
}

int main(int argc, char** argv) {
    if (argc < 2) { fprintf(stderr, "Uso: %s schedule.txt\n", argv[0]); return 1; }
    TaskList tl; if (read_tasks(argv[1], &tl) != 0) return 1;

    // Copia e ordena por chegada
    Task* a = (Task*)malloc(sizeof(Task)*tl.n);
    for (int i=0;i<tl.n;i++) a[i] = tl.v[i];
    qsort(a, tl.n, sizeof(Task), cmp_arrival);

    // Para Gantt
    const char* labels[1024]; int starts[1024]; int ends[1024]; int segs=0;

    int time = 0, cpu_busy = 0;
    int first_arrival = 1e9; for (int i=0;i<tl.n;i++) if (a[i].arrival < first_arrival) first_arrival = a[i].arrival;

    printf("[FCFS] Ordem de execução:\n");
    for (int i=0;i<tl.n;i++) {
        if (time < a[i].arrival) {
            // CPU ociosa
            time = a[i].arrival;
        }
        a[i].start_time = time;
        a[i].waiting_time = a[i].start_time - a[i].arrival;
        time += a[i].burst;
        a[i].finish_time = time;
        a[i].turnaround = a[i].finish_time - a[i].arrival;
        a[i].response = a[i].start_time - a[i].arrival;
        cpu_busy += a[i].burst;

        labels[segs] = a[i].name;
        starts[segs] = a[i].start_time;
        ends[segs] = a[i].finish_time;
        segs++;

        printf("  %s: start=%d finish=%d wait=%d turnaround=%d\n",
            a[i].name, a[i].start_time, a[i].finish_time, a[i].waiting_time, a[i].turnaround);
    }

    int makespan = time - (first_arrival < 0 ? 0 : first_arrival);
    print_gantt(labels, starts, ends, segs);
    print_metrics(a, tl.n, makespan, cpu_busy);

    free(a); free_tasks(&tl); return 0;
}