#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[64];
    int arrival;
    int burst;
    int priority;
    int start_time, finish_time, waiting_time, turnaround, response;
} Task;
typedef struct { Task* v; int n; int quantum_default; } TaskList;

int read_tasks(const char* path, TaskList* out);
void free_tasks(TaskList* tl);
void print_gantt(const char** labels, const int* starts, const int* ends, int m);
void print_metrics(Task* tasks, int n, int makespan, int cpu_busy);

typedef struct {
    int rem;
    int seen; // já iniciou alguma vez? para response time
    int last_finish; // para acumular espera entre fatias
} Runtime;

int main(int argc, char** argv) {
    if (argc < 2) { fprintf(stderr, "Uso: %s schedule.txt [quantum]\n", argv[0]); return 1; }
    TaskList tl; if (read_tasks(argv[1], &tl) != 0) return 1;
    int quantum = (argc >= 3) ? atoi(argv[2]) : (tl.quantum_default>0 ? tl.quantum_default : 3);
    if (quantum <= 0) quantum = 3;

    Runtime* rt = (Runtime*)calloc(tl.n, sizeof(Runtime));
    for (int i=0;i<tl.n;i++) { rt[i].rem = tl.v[i].burst; rt[i].seen=0; rt[i].last_finish = tl.v[i].arrival; }

    const char* labels[4096]; int starts[4096]; int ends[4096]; int segs=0;

    int time=0, finished=0, cpu_busy=0;
    int first_arrival = 1e9; for (int i=0;i<tl.n;i++) if (tl.v[i].arrival < first_arrival) first_arrival = tl.v[i].arrival;

    printf("[RR q=%d] Fatias:\n", quantum);
    while (finished < tl.n) {
        int progressed = 0;
        for (int i=0;i<tl.n;i++) {
            if (rt[i].rem <= 0) continue;
            if (tl.v[i].arrival > time) continue;

            int slice = rt[i].rem < quantum ? rt[i].rem : quantum;
            int start = time;
            time += slice;
            rt[i].rem -= slice;
            progressed = 1; cpu_busy += slice;

            if (!rt[i].seen) { tl.v[i].start_time = start; tl.v[i].response = tl.v[i].start_time - tl.v[i].arrival; rt[i].seen=1; }
            // espera desde a última vez que terminou/chegou até agora
            int waited = start - rt[i].last_finish; if (waited > 0) tl.v[i].waiting_time += waited;

            labels[segs] = tl.v[i].name; starts[segs] = start; ends[segs] = time; segs++;

            rt[i].last_finish = time;
            if (rt[i].rem == 0) { tl.v[i].finish_time = time; tl.v[i].turnaround = tl.v[i].finish_time - tl.v[i].arrival; finished++; }
        }
        if (!progressed) {
            int next_arrival = 1e9;
            for (int i=0;i<tl.n;i++) if (rt[i].rem>0 && tl.v[i].arrival < next_arrival) next_arrival = tl.v[i].arrival;
            if (next_arrival > time) time = next_arrival;
        }
    }

    int makespan = time - (first_arrival < 0 ? 0 : first_arrival);
    print_gantt(labels, starts, ends, segs);
    print_metrics(tl.v, tl.n, makespan, cpu_busy);

    free(rt); free_tasks(&tl); return 0;
}